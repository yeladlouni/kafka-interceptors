import org.apache.kafka.clients.admin.*;
import org.apache.kafka.common.ElectionType;
import org.apache.kafka.common.TopicPartition;

import java.util.*;
import java.util.concurrent.ExecutionException;

public class Example {
    AdminClient admin;
    Collection<String> TOPIC_LIST = Arrays.asList("customers");
    String TOPIC_NAME = "customers";
    int NUM_PARTITIONS = 1;
    Example() {
        Properties props = new Properties();
        props.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        admin = AdminClient.create(props);
    }
    void addPartitions() throws InterruptedException, ExecutionException {
        Map<String, NewPartitions> newPartitions = new HashMap<>();
        newPartitions.put(TOPIC_NAME, NewPartitions.increaseTo(NUM_PARTITIONS + 2));
        admin.createPartitions(newPartitions).all().get();
    }

    void deleteRecords() throws InterruptedException, ExecutionException {
        Map<TopicPartition, OffsetSpec> requestOlderOffsets = new HashMap<>();
        Map<TopicPartition, ListOffsetsResult.ListOffsetsResultInfo> olderOffsets =
                admin.listOffsets(requestOlderOffsets).all().get();
        Map<TopicPartition, RecordsToDelete> recordsToDelete = new HashMap<>();

        for (Map.Entry<TopicPartition, ListOffsetsResult.ListOffsetsResultInfo> e: olderOffsets.entrySet()) {
            recordsToDelete.put(e.getKey(), RecordsToDelete.beforeOffset(e.getValue().offset()));
            admin.deleteRecords(recordsToDelete).all().get();
        }
    }

    void leaderElection() throws InterruptedException, ExecutionException {
        Set<TopicPartition> electableTopics = new HashSet<>();
        electableTopics.add(new TopicPartition(TOPIC_NAME, 0));
        admin.electLeaders(ElectionType.PREFERRED, electableTopics).all().get();
    }

    void reassignReplicas() throws InterruptedException, ExecutionException {
        Map<TopicPartition, Optional<NewPartitionReassignment>> reassignment = new HashMap<>();
        reassignment.put(new TopicPartition(TOPIC_NAME, 0),
                Optional.of(new NewPartitionReassignment(Arrays.asList(0, 1))));
        reassignment.put(new TopicPartition(TOPIC_NAME, 1),
                Optional.of(new NewPartitionReassignment(Arrays.asList(1))));
        reassignment.put(new TopicPartition(TOPIC_NAME, 2),
                Optional.of(new NewPartitionReassignment(Arrays.asList(1, 0))));
        reassignment.put(new TopicPartition(TOPIC_NAME, 3),
                Optional.empty());

        admin.alterPartitionReassignments(reassignment).all().get();

        System.out.println("currently reassigning: " + admin.listPartitionReassignments().reassignments().get());
        DescribeTopicsResult demoTopic = admin.describeTopics(TOPIC_LIST);
        TopicDescription topicDescription = demoTopic.topicNameValues().get(TOPIC_NAME).get();
        System.out.println("Description of demo topic: " + topicDescription);

    }

    public static void main(String[] args) throws InterruptedException, ExecutionException {
        Example example = new Example();
        example.addPartitions();
        example.deleteRecords();
        example.leaderElection();
        example.reassignReplicas();
    }
}
