import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.DescribeClusterResult;
import scala.Int;

import java.util.Properties;
import java.util.concurrent.ExecutionException;

public class Example {
    public Example() throws InterruptedException, ExecutionException {
        Properties props = new Properties();
        props.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");

        AdminClient adminClient = AdminClient.create(props);


        DescribeClusterResult cluster = adminClient.describeCluster();
        cluster.nodes().get().forEach(System.out::println);
        System.out.printf(cluster.controller().get().toString());
    }

    public static void main(String[] args) throws InterruptedException, ExecutionException{
        new Example();
    }
}
