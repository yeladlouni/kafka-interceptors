<?php

namespace App\Controller;

use Symfony\Contracts\HttpClient\HttpClientInterface;
use Symfony\Component\HttpFoundation\JsonResponse;

class TopicController
{
    public function __construct(
        private HttpClientInterface $client,
    ) {
    }

    public function show(): JsonResponse
    {
        $response = $this->client->request('GET', 'http://rest-proxy:8082/topics/');
        $content = $response->toArray();


        return new JsonResponse($content);

        
    }
}