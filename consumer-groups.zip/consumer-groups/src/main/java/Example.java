import org.apache.kafka.clients.admin.*;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;


import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class Example {
    public Example() {
        Properties props = new Properties();
        props.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        AdminClient admin = AdminClient.create(props);

        try {

            final String CONSUMER_GROUP = "_confluent-controlcenter-7-4-0-1-command";

            // List of consumer groups
            admin.listConsumerGroups().valid().get().forEach(System.out::println);

            // Describe consumer groups
            ConsumerGroupDescription groupDescription = admin.describeConsumerGroups(Arrays.asList("_confluent-controlcenter-7-4-0-1-command",
                    "_confluent-controlcenter-7-4-0-1-command")).describedGroups().get(CONSUMER_GROUP).get();

            Map<TopicPartition, OffsetAndMetadata> offsets = admin.listConsumerGroupOffsets(CONSUMER_GROUP).partitionsToOffsetAndMetadata().get();
            Map<TopicPartition, OffsetSpec> requestLatestOffsets = new HashMap<>();

            for (TopicPartition tp: offsets.keySet()) {
                requestLatestOffsets.put(tp, OffsetSpec.latest());
            }

            Map<TopicPartition, ListOffsetsResult.ListOffsetsResultInfo> latestOffsets =
                    admin.listOffsets(requestLatestOffsets).all().get();

            for (Map.Entry<TopicPartition, OffsetAndMetadata> e: offsets.entrySet()) {
                String topic = e.getKey().topic();
                int partition = e.getKey().partition();
                long commitedOffset = e.getValue().offset();
                long latestOffset = latestOffsets.get(e.getKey()).offset();

                System.out.printf("Consumer group: %s\nTopic: %s\nPartition: %d\nCommited Offset: %d\nLatest Offset: %d",
                        CONSUMER_GROUP, topic, partition, commitedOffset, latestOffset);
            }

            System.out.println(groupDescription);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Example();
    }
}
